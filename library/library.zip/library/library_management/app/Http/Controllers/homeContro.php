<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class homeContro extends Controller
{
    //
}
